# Project Name: ZERODHA FRONTEND CLONE

This project contains a simple HTML file with an inline CSS styled navigation bar.

## Description

This repository contains a single HTML file that demonstrates a basic navigation bar styled using inline CSS. The navigation bar includes links to different sections of the page.

## File Structure

- `index.html`: Contains the HTML markup for the webpage.
  
## Usage

To view the webpage locally:
1. Clone this repository to your local machine using `git clone <repository-url>`.
2. Navigate to the project directory: `cd <project-directory>`.
3. Open `index.html` in your preferred web browser.
